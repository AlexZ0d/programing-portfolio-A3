using Godot;
using System;

public class Start : Button
{
	
	public override void _Ready()
	{
		
	}


}
