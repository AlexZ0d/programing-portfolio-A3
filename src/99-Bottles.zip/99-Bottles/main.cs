using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Hello World");

   int bruh = 99;

    Console.WriteLine (bruh + " bottle of root beer on the Wall," + bruh + " bottles of root beer");

 while(bruh > 0){
    bruh = bruh -1;
    if( bruh != 0){
       Console.WriteLine (bruh + " bottle of root beer on the Wall," + bruh + " bottles of root beer");
    }
  }
  }


}